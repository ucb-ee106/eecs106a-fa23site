import sympy
from sympy.core.function import diff
from sympy.simplify.simplify import simplify

# Constants
L = sympy.Symbol("L") # Length of arm
m = sympy.Symbol("m") # mass of each arm
I = sympy.Symbol("I") # moment of inertia of each arm
g = sympy.Symbol("g") # acceleration due to gravity

# Define generalized coordinates as functions of time
# and specify their derivatives for prettier computation
t = sympy.Symbol("t")
q1_func = sympy.Function("q1")
q2_func = sympy.Function("q2")
q1_dot_func = sympy.Function("qdot1")
q2_dot_func = sympy.Function("qdot2")
q1_ddot_func = sympy.Function("qddot1")
q2_ddot_func = sympy.Function("qddot2")

q1_func.fdiff = lambda self, argindex=1: q1_dot_func(self.args[argindex-1])
q2_func.fdiff = lambda self, argindex=1: q2_dot_func(self.args[argindex-1])
q1_dot_func.fdiff = lambda self, argindex=1: q1_ddot_func(self.args[argindex-1])
q2_dot_func.fdiff = lambda self, argindex=1: q2_ddot_func(self.args[argindex-1])

# Generalized coordinates
q1 = q1_func(t)
q2 = q2_func(t)
q = sympy.Matrix([
    [q1],
    [q2]
])

# First derivatives
q1_dot = sympy.diff(q1, t) 
q2_dot = sympy.diff(q2, t)
q_dot = sympy.diff(q, t)

# Second derivatives
q1_ddot = sympy.diff(q1, t, t) 
q2_ddot = sympy.diff(q2, t, t)
q_ddot = sympy.diff(q, t, t)

# Find the xy position of each center of mass
cm1_xy = sympy.Matrix([
        [...],
        [...]
    ])
cm2_xy = sympy.Matrix([
    [...],
    [...]
])

vars = [L, m, I, g, q1, q2, q1_dot, q2_dot, q1_ddot, q2_ddot]

# Find the velocity vector for each center of mass
# sympy.diff(arg1, arg2) will be useful here (takes derivative of first argument with respect to the second)
cm1_xy_vel = sympy.diff(..., ...)
cm2_xy_vel = sympy.diff(..., ...)

# Now, we need to find the kinetic energy T
# This will be the sum of the translational kinetic energy and rotational kinetic energy

# Get the squared magnitude of the velocity for each center of mass for the translational kinetic energy
# Use the dot product to do this
cm1_vel_squared = ...
cm2_vel_squared = ...
# sympy.simplify will take in an expression and clean it up
cm1_vel_squared = sympy.simplify(cm1_vel_squared)
cm2_vel_squared = sympy.simplify(cm2_vel_squared)

# Get the translational kinetic energy
T_t = ...
T_t = sympy.simplify(T_t)

# Get the rotional kinetic energy
T_r = ...
T_r = sympy.simplify(T_r)

# Get total kinetic energy
T = ...
# We're going to rewrite T to group together some useful terms
T = sympy.expand(T)
T = sympy.collect(T, [q1_dot*q2_dot, q1_dot**2, q2_dot**2])
T_func = sympy.lambdify(vars, T, "numpy")

# Next, we'll get the potential energy V
# The only potential energy in our system is due to gravity
V = ...
V = sympy.simplify(V)
V_func = sympy.lambdify(vars, V, "numpy")

# Now we compute our Lagrangian
L = ...

# Finding our equations of motion is just a matter of taking a few derivatives now
# sympy.diff(arg1, arg2) will be useful here (takes derivative of first argument with respect to the second)
# arg1, arg2 can each be scalars/vectors/matrices
dL_dq = sympy.diff(..., ...)
dL_dq_dot = sympy.diff(..., ...)
dL_dq_dot_dt = sympy.diff(..., ...)
dL_dq_dot_dt = sympy.simplify(dL_dq_dot_dt)
dL_dq_func = sympy.lambdify(vars, dL_dq, "numpy")
dL_dq_dot_dt_func = sympy.lambdify(vars, dL_dq_dot_dt, "numpy")

# We can now directly compute our dynamics
upsilon = ...

# Now, we need to factor this expression into something of the form
# M(q, q_dot)*q_ddot + C(q, q_dot)*q_dot + N(q) = upsilon
# The most straightforward way is probably to proceed one row at a time
# expr.coeff(arg1) will be useful here (gets all coefficinets of arg1 in the expression)
# There are some limiatations though. Unfortuantely, (x**2).coef(x) will not return x.
# So be careful with squared terms! You can do .coeff(x**2)*x to account for this.

M = sympy.Matrix([
    [..., ...],
    [..., ...]
])
M_func = sympy.lambdify(vars, M, "numpy")

# Note there multiple possible answers for the C matrix
# Also make sure to avoid duplicates when finding coefficients for an expression like
# q1_dot*q2_dot
C = sympy.Matrix([
    [..., ...],
    [..., ...],
])
C_func = sympy.lambdify(vars, C, "numpy")

# We can find N in terms of the M, C, and upsilon 
N = ...
N = sympy.simplify(N)
N_func = sympy.lambdify(vars, N, "numpy")

if __name__ == "__main__":
    print("\nXY Position of first center of mass:")
    sympy.pprint(cm1_xy)

    print("\nXY Position of second center of mass:")
    sympy.pprint(cm2_xy)

    print("\nXY Velocity of first center of mass:")
    sympy.pprint(cm1_xy_vel)

    print("\nXY Velocity of second center of mass:")
    sympy.pprint(cm2_xy_vel)

    print("\nXY Velocity of second center of mass:")
    sympy.pprint(cm2_xy_vel)

    print("\nTranslational kinetic energy of system:")
    sympy.pprint(T_t)

    print("\nRotational kinetic energy of system:")
    sympy.pprint(T_r)

    print("\nTotal kinetic energy of system:")
    sympy.pprint(T)

    print("\nTotal potential energy of system:")
    sympy.pprint(V)

    print("\nLagrangian:")
    sympy.pprint(L)

    print("\nSystem Dynamics:")
    sympy.pprint(upsilon)

    print("\nM matrix:")
    sympy.pprint(M)

    print("\nC matrix:")
    sympy.pprint(C)

    print("\nN vector:")
    sympy.pprint(N)