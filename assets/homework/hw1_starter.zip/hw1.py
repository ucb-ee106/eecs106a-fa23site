import numpy as np

def get_corners(xy, theta, corner1, corner2, corner3, corner4):
    """
    Get the corners of the car given the 2D pose of the car.
    TODO: Make sure that this function returns the correct position of each corner of the car relative to the world frame.

    Parameters:
        xy (2x1 np array): The xy position of the car
        theta (float): The angle the car. theta=0 corresponds to the car pointing along the x-axis
        corner1, corner2, corner3, corner4 (2x1 np array): Position of each corner of the car relative to the car's frame
    Returns:
        c1, c2, c3, c4: Position of each corner of the car relative to the world frame
    """
    # Are these coordinates in the right frame?
    c1 = xy + corner1
    c2 = xy + corner2
    c3 = xy + corner3
    c4 = xy + corner4
    return c1, c2, c3, c4